#!/usr/bin/env python3

from ..games.brain_progression import progression_game


def main():
    progression_game()


if __name__ == '__main__':
    main()

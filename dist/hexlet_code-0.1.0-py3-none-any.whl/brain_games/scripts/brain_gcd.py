#!/usr/bin/env python3

from ..games.brain_gcd import gcd_game


def main():
    gcd_game()


if __name__ == '__main__':
    main()

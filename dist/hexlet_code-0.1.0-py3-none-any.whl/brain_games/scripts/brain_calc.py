#!/usr/bin/env python3

from ..games.brain_calc import calc_game


def main():
    calc_game()


if __name__ == '__main__':
    main()

#!/usr/bin/env python3

from ..games.brain_prime import prime_game


def main():
    prime_game()


if __name__ == '__main__':
    main()

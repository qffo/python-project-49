#!/usr/bin/env python3

from ..games.brain_calc import calc_game


def main():
    # print("Welcome to the Brain Games!")
    calc_game()


if __name__ == '__main__':
    main()

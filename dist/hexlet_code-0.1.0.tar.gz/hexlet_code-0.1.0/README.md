### Hexlet tests and linter status:
[![Actions Status](https://github.com/qffo/python-project-49/actions/workflows/hexlet-check.yml/badge.svg)](https://github.com/qffo/python-project-49/actions)
[![Maintainability](https://api.codeclimate.com/v1/badges/9ce19e7fca0f7255c50b/maintainability)](https://codeclimate.com/github/qffo/python-project-49/maintainability)

<h3>Package install</h3>

[![asciicast](https://asciinema.org/a/1VugT5fPz3YrC68VYJlNzmqXn.svg)](https://asciinema.org/a/1VugT5fPz3YrC68VYJlNzmqXn)

<h3>Brain Even. Run game and game process</h3>

[![asciicast](https://asciinema.org/a/scel1ghZSXwfJHCcOl07mq3qu.svg)](https://asciinema.org/a/scel1ghZSXwfJHCcOl07mq3qu)

<h3>Brain Calc. Run game and game process</h3>

[![asciicast](https://asciinema.org/a/k68Gdtva8hPYTvMNiG5lJsDHH.svg)](https://asciinema.org/a/k68Gdtva8hPYTvMNiG5lJsDHH)

<h3>Brain Gcd. Run game and game process</h3>

[![asciicast](https://asciinema.org/a/Pptcr1PKXViEs6Q8lKir09sk0.svg)](https://asciinema.org/a/Pptcr1PKXViEs6Q8lKir09sk0)
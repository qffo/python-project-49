### Hexlet tests and linter status:
[![Actions Status](https://github.com/qffo/python-project-49/actions/workflows/hexlet-check.yml/badge.svg)](https://github.com/qffo/python-project-49/actions)
[![Maintainability](https://api.codeclimate.com/v1/badges/9ce19e7fca0f7255c50b/maintainability)](https://codeclimate.com/github/qffo/python-project-49/maintainability)

<h3>Package install</h3>

[![asciicast](https://asciinema.org/a/6Ymvfib9989zidq00eRQ8kchl.svg)](https://asciinema.org/a/6Ymvfib9989zidq00eRQ8kchl)

<h3>Run game brain-even and game process</h3>

[![asciicast](https://asciinema.org/a/YsdSsOEuFvBPWt6J5Xt676l2B.svg)](https://asciinema.org/a/YsdSsOEuFvBPWt6J5Xt676l2B)
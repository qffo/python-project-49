### Hexlet tests and linter status:
[![Actions Status](https://github.com/qffo/python-project-49/actions/workflows/hexlet-check.yml/badge.svg)](https://github.com/qffo/python-project-49/actions)
[![Maintainability](https://api.codeclimate.com/v1/badges/9ce19e7fca0f7255c50b/maintainability)](https://codeclimate.com/github/qffo/python-project-49/maintainability)
### Hexlet tests and linter status:
[![Actions Status](https://github.com/qffo/python-project-49/actions/workflows/hexlet-check.yml/badge.svg)](https://github.com/qffo/python-project-49/actions)